# 1N1002B_2023
Este repositorio es de apoyo académico de mis estudiantes del bloque: Desarrollo de proyectos de análisis de datos (Gpo 301 y Gpo 302)
